# include <SFML\Graphics.hpp>
# include <string>
#include "Main.h"
#include "Level.h"
//# include "QuestionsBank.h"

class Game
{
public:
	Game();
	void run();
	~Game();
};